package com.keely.welcomehome;
import android.app.*;
import android.content.*;
import android.net.*;
import android.net.nsd.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class ListenerService extends Service {
  static final int PORT = 8765;
  LinkedList<String> logs = new LinkedList<>();
  void log(String s) { logs.add(new Date() + " " + s); if (logs.size() > 15) logs.removeFirst(); }
  ServerSocket ss; Thread t; boolean started; long lastAt = 0; String lastTxt = "never";
  Handler h = new Handler(Looper.getMainLooper()); NsdManager.RegistrationListener reg;

  public IBinder onBind(Intent i) { return null; }

  public int onStartCommand(Intent i, int f, int id) {
    if (!started) {
      started = true; fg();
      ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wh:svc").acquire();
      listen(); advertise();
      ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback() {
        public void onAvailable(Network n) { log("network changed"); advertise(); listen(); }
      });
      h.postDelayed(new Runnable() { public void run() { listen(); h.postDelayed(this, 60000); } }, 60000);
    }
    return START_STICKY;
  }

  void fg() {
    if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("wh", "Welcome Home", NotificationManager.IMPORTANCE_MIN));
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "wh") : new Notification.Builder(this);
    startForeground(1, b.setContentTitle("Welcome Home is listening").setSmallIcon(android.R.drawable.ic_menu_compass).build());
  }

  void listen() {
    if (t != null && t.isAlive() && ss != null && !ss.isClosed()) return;
    t = new Thread(() -> {
      try {
        ss = new ServerSocket(); ss.setReuseAddress(true); ss.bind(new InetSocketAddress(PORT));
        while (!ss.isClosed()) { Socket s = ss.accept(); new Thread(() -> handle(s)).start(); }
      } catch (Exception e) { log("listener error: " + e); try { if (ss != null) ss.close(); } catch (Exception x) {} }
    });
    t.start();
  }

  void advertise() {
    try {
      NsdManager n = (NsdManager) getSystemService(NSD_SERVICE);
      if (reg != null) { try { n.unregisterService(reg); } catch (Exception e) {} }
      NsdServiceInfo i = new NsdServiceInfo(); i.setServiceName("WelcomeHome"); i.setServiceType("_http._tcp."); i.setPort(PORT);
      reg = new NsdManager.RegistrationListener() {
        public void onRegistrationFailed(NsdServiceInfo s, int c) {}
        public void onUnregistrationFailed(NsdServiceInfo s, int c) {}
        public void onServiceRegistered(NsdServiceInfo s) {}
        public void onServiceUnregistered(NsdServiceInfo s) {}
      };
      n.registerService(i, NsdManager.PROTOCOL_DNS_SD, reg);
    } catch (Exception e) {}
  }

  void handle(Socket s) {
    try (Socket c = s) {
      String l = new BufferedReader(new InputStreamReader(c.getInputStream())).readLine();
      String p = l == null ? "/" : l.split(" ")[1], body;
      if (p.startsWith("/arrive")) { arrive(); body = "ok"; }
      else if (p.startsWith("/page?url=")) { getSharedPreferences("wh", 0).edit().putString("url", URLDecoder.decode(p.substring(10), "UTF-8")).apply(); log("screen address saved"); body = "Screen address saved"; }
      else if (p.startsWith("/tv?mac=")) { getSharedPreferences("wh", 0).edit().putString("mac", URLDecoder.decode(p.substring(8), "UTF-8")).apply(); body = "TV address saved"; }
      else body = "Welcome Home listener is running.\nArrive: http://" + ip() + ":" + PORT + "/arrive\nLast arrival: " + lastTxt + "\n\nRecent events:\n" + android.text.TextUtils.join("\n", logs);
      c.getOutputStream().write(("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\n" + body).getBytes());
    } catch (Exception e) {}
  }

  void arrive() {
    long n = System.currentTimeMillis(); if (n - lastAt < 15000) return;
    lastAt = n; lastTxt = new Date().toString(); log("arrive");
    wol();
    h.postDelayed(() -> startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)), 3000);
  }

  void wol() {
    try {
      String[] p = getSharedPreferences("wh", 0).getString("mac", "b8:d8:2d:85:9a:1c").split("[:-]"); if (p.length != 6) { log("no TV address saved"); return; }
      byte[] m = new byte[102]; Arrays.fill(m, 0, 6, (byte) 0xff);
      for (int j = 0; j < 16; j++) for (int k = 0; k < 6; k++) m[6 + j * 6 + k] = (byte) Integer.parseInt(p[k], 16);
      DatagramSocket d = new DatagramSocket(); d.setBroadcast(true);
      for (int r = 0; r < 3; r++) { d.send(new DatagramPacket(m, m.length, InetAddress.getByName("255.255.255.255"), 9)); Thread.sleep(300); }
      d.close(); log("wake sent");
    } catch (Exception e) { log("wake failed: " + e); }
  }

  String ip() {
    try { for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) for (InetAddress a : Collections.list(n.getInetAddresses())) if (!a.isLoopbackAddress() && a instanceof Inet4Address) return a.getHostAddress(); } catch (Exception e) {}
    return "?";
  }
}
