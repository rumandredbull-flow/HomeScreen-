package com.keely.welcomehome;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
  public void onReceive(Context c, Intent i) { c.startForegroundService(new Intent(c, ListenerService.class)); }
}
