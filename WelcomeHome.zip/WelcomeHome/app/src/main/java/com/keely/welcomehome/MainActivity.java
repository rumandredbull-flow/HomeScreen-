package com.keely.welcomehome;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
  WebView w; String cur = "";

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
    w = new WebView(this); setContentView(w); w.setBackgroundColor(0xFF1B1FD0);
    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
    w.addJavascriptInterface(new Object() {
      @JavascriptInterface public void launch(String n) { runOnUiThread(() -> open(n)); }
      @JavascriptInterface public void home() { runOnUiThread(() -> goHome()); }
    }, "Android");
    w.loadUrl(local()); refresh();
    startForegroundService(new Intent(this, ListenerService.class));
    try { if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); } catch (Exception e) {}
  }

  @Override protected void onResume() { super.onResume(); if (w != null) refresh(); }

  @Override public void onWindowFocusChanged(boolean f) {
    super.onWindowFocusChanged(f);
    if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  }

  String local() { java.io.File f = new java.io.File(getFilesDir(), "index.html"); return f.exists() ? "file://" + f.getPath() : "file:///android_asset/index.html"; }

  // Pulls the latest screen from the saved web address (if any) and reloads when it changed.
  void refresh() {
    String u = getSharedPreferences("wh", 0).getString("url", ""); if (u.isEmpty()) return;
    new Thread(() -> { try {
      java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(u).openConnection(); c.setConnectTimeout(5000); c.setReadTimeout(8000);
      java.io.InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
      while ((n = in.read(b)) > 0) o.write(b, 0, n);
      byte[] d = o.toByteArray(); String s = new String(d, "UTF-8"); if (d.length < 200 || s.equals(cur)) return; cur = s;
      java.io.FileOutputStream fo = new java.io.FileOutputStream(new java.io.File(getFilesDir(), "index.html")); fo.write(d); fo.close();
      runOnUiThread(() -> w.loadUrl(local()));
    } catch (Exception e) {} }).start();
  }

  // Controller: A acts as Enter; B (or Back) closes a popup first, otherwise goes to the Superbox home menu.
  @Override public boolean dispatchKeyEvent(KeyEvent e) {
    int k = e.getKeyCode();
    if (k == KeyEvent.KEYCODE_BUTTON_B || k == KeyEvent.KEYCODE_BACK) {
      if (e.getAction() == KeyEvent.ACTION_UP) w.evaluateJavascript("window.onBack?window.onBack():false", v -> { if (!"true".equals(v)) goHome(); });
      return true;
    }
    if (k == KeyEvent.KEYCODE_BUTTON_A) return super.dispatchKeyEvent(new KeyEvent(e.getAction(), KeyEvent.KEYCODE_ENTER));
    return super.dispatchKeyEvent(e);
  }

  void goHome() { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }

  // Finds an installed app by name (no package names needed) and opens it.
  void open(String name) {
    PackageManager pm = getPackageManager();
    for (ApplicationInfo a : pm.getInstalledApplications(0)) {
      String l = pm.getApplicationLabel(a).toString().toLowerCase().replace(" ", "");
      if (!l.contains(name)) continue;
      Intent i = pm.getLeanbackLaunchIntentForPackage(a.packageName);
      if (i == null) i = pm.getLaunchIntentForPackage(a.packageName);
      if (i != null) { startActivity(i); return; }
    }
    Toast.makeText(this, name + " not found", Toast.LENGTH_LONG).show();
  }
}
