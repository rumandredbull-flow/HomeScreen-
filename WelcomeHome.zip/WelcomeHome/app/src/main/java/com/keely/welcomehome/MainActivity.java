package com.keely.welcomehome;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
  // Optional: put a hosted copy of the screen here to update it without rebuilding. Empty = use the bundled copy.
  static final String REMOTE_URL = "";
  WebView w;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
    w = new WebView(this); setContentView(w); w.setBackgroundColor(0xFF1B1FD0);
    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    w.addJavascriptInterface(new Object() {
      @JavascriptInterface public void launch(String n) { runOnUiThread(() -> open(n)); }
    }, "Android");
    w.setWebViewClient(new WebViewClient() {
      @Override public void onReceivedError(WebView v, int c, String d, String u) {
        if (u != null && u.startsWith("http")) v.loadUrl("file:///android_asset/index.html");
      }
    });
    w.loadUrl(REMOTE_URL.isEmpty() ? "file:///android_asset/index.html" : REMOTE_URL);
    startForegroundService(new Intent(this, ListenerService.class));
    try { if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); } catch (Exception e) {}
  }

  @Override public void onWindowFocusChanged(boolean f) {
    super.onWindowFocusChanged(f);
    if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  }

  // Finds an installed app by name (no package names needed) and opens it.
  void open(String name) {
    PackageManager pm = getPackageManager();
    for (ApplicationInfo a : pm.getInstalledApplications(0)) {
      String l = pm.getApplicationLabel(a).toString().toLowerCase().replace(" ", "");
      if (!l.contains(name)) continue;
      Intent i = pm.getLeanbackLaunchIntentForPackage(a.packageName);
      if (i == null) i = pm.getLaunchIntentForPackage(a.packageName);
      if (i != null) { startActivity(i); return; }
    }
    Toast.makeText(this, name + " not found", Toast.LENGTH_LONG).show();
  }
}
