package com.keely.welcomehome;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
  WebView w; String cur = "";

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
    w = new WebView(this); setContentView(w); w.setBackgroundColor(0xFF0F1419);
    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
    w.addJavascriptInterface(new Object() {
      @JavascriptInterface public void launch(String n) { runOnUiThread(() -> open(n)); }
      @JavascriptInterface public void home() { runOnUiThread(() -> goHome()); }
      @JavascriptInterface public void fetchText(String u, String cb) { fetchAsync(u, cb); }
      @JavascriptInterface public String icon(String n) { return iconOf(n); }
    }, "Android");
    w.loadUrl(local()); refresh();
    startForegroundService(new Intent(this, ListenerService.class));
    try { if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); } catch (Exception e) {}
  }

  @Override protected void onResume() { super.onResume(); if (w != null) refresh(); }

  @Override public void onWindowFocusChanged(boolean f) {
    super.onWindowFocusChanged(f);
    if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  }

  String local() { java.io.File f = new java.io.File(getFilesDir(), "index.html"); return f.exists() ? "file://" + f.getPath() : "file:///android_asset/index.html"; }

  // Pulls the latest screen from the saved web address (if any) and reloads when it changed.
  void refresh() {
    String u = getSharedPreferences("wh", 0).getString("url", ""); if (u.isEmpty()) return;
    new Thread(() -> { try {
      java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(u).openConnection(); c.setConnectTimeout(5000); c.setReadTimeout(8000);
      java.io.InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
      while ((n = in.read(b)) > 0) o.write(b, 0, n);
      byte[] d = o.toByteArray(); String s = new String(d, "UTF-8"); if (d.length < 200 || s.equals(cur)) return; cur = s;
      java.io.FileOutputStream fo = new java.io.FileOutputStream(new java.io.File(getFilesDir(), "index.html")); fo.write(d); fo.close();
      runOnUiThread(() -> w.loadUrl(local()));
    } catch (Exception e) {} }).start();
  }

  // Controller: A acts as Enter; B (or Back) closes a popup first, otherwise goes to the Superbox home menu.
  @Override public boolean dispatchKeyEvent(KeyEvent e) {
    int k = e.getKeyCode();
    if (k == KeyEvent.KEYCODE_BUTTON_B || k == KeyEvent.KEYCODE_BACK) {
      if (e.getAction() == KeyEvent.ACTION_UP) w.evaluateJavascript("window.onBack?window.onBack():false", v -> { if (!"true".equals(v)) goHome(); });
      return true;
    }
    if (k == KeyEvent.KEYCODE_BUTTON_A) return super.dispatchKeyEvent(new KeyEvent(e.getAction(), KeyEvent.KEYCODE_ENTER));
    return super.dispatchKeyEvent(e);
  }

  // Downloads a web page natively (no browser CORS limits) and hands the text to a JS function in the page.
  void fetchAsync(String u, String cb) {
    new Thread(() -> { String out = "";
      try {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(12000); c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/120 Safari/537.36");
        java.io.InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
        while ((n = in.read(b)) > 0 && o.size() < 1500000) o.write(b, 0, n);
        out = o.toString("UTF-8");
      } catch (Exception e) {}
      final String js = cb + "(" + org.json.JSONObject.quote(out) + ")";
      runOnUiThread(() -> w.evaluateJavascript(js, null));
    }).start();
  }

  // Returns the installed app's TV banner (or icon) as a base64 PNG so the page can show the real artwork.
  String iconOf(String name) {
    try {
      PackageManager pm = getPackageManager();
      for (ApplicationInfo a : pm.getInstalledApplications(0)) {
        String l = pm.getApplicationLabel(a).toString().toLowerCase().replace(" ", "");
        if (!l.contains(name)) continue;
        android.graphics.drawable.Drawable d = pm.getApplicationBanner(a); boolean banner = d != null;
        if (d == null) d = pm.getApplicationIcon(a);
        int w2 = banner ? 480 : 256, h2 = banner ? 270 : 256;
        android.graphics.Bitmap bm = android.graphics.Bitmap.createBitmap(w2, h2, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas cv = new android.graphics.Canvas(bm); d.setBounds(0, 0, w2, h2); d.draw(cv);
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, o);
        return (banner ? "B:" : "I:") + android.util.Base64.encodeToString(o.toByteArray(), android.util.Base64.NO_WRAP);
      }
    } catch (Exception e) {}
    return "";
  }

  void goHome() { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }

  // Finds an installed app by name (no package names needed) and opens it.
  void open(String name) {
    PackageManager pm = getPackageManager();
    for (ApplicationInfo a : pm.getInstalledApplications(0)) {
      String l = pm.getApplicationLabel(a).toString().toLowerCase().replace(" ", "");
      if (!l.contains(name)) continue;
      Intent i = pm.getLeanbackLaunchIntentForPackage(a.packageName);
      if (i == null) i = pm.getLaunchIntentForPackage(a.packageName);
      if (i != null) { startActivity(i); return; }
    }
    Toast.makeText(this, name + " not found", Toast.LENGTH_LONG).show();
  }
}
